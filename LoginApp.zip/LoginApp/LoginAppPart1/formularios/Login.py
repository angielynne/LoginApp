import tkinter as tk
import util.generic as utl
from tkinter import messagebox
from users import Users
from PIL import Image, ImageTk

class Login(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Login")
        self.resizable(False, False)
        utl.centrar_ventana(self, 800, 500)
        self.logo = utl.leer_imagen(r"LoginApp/LoginAppPart1/imagenes/logo.png", (300, 100))
        self.user = utl.leer_imagen(r"LoginApp/LoginAppPart1/imagenes/login.png", (64, 64))

        self.frame_logo = tk.Frame(self, bd=0, relief=tk.SOLID)
        self.frame_logo.pack(side=tk.TOP, anchor=tk.NW)
        self.llogo = tk.Label(self.frame_logo, image=self.logo)
        self.llogo.pack(padx=5, pady=5)

        self.frame_user = tk.Frame(self, bd=0, width=300, relief=tk.SOLID)
        self.frame_user.pack(side=tk.LEFT, fill=tk.Y)
        self.uuser = tk.Label(self.frame_user, image=self.user)
        self.uuser.pack(padx=5, pady=20)

        self.frame_form = tk.Frame(self, bd=0, relief=tk.SOLID)
        self.frame_form.pack(side=tk.RIGHT, expand=tk.YES, fill=tk.BOTH)

        self.create_widgets()

    def create_widgets(self):
        tk.Label(self.frame_form, text="Usuario:", font=('Times', 14)).pack(padx=10, pady=5)
        self.cusuario = tk.Entry(self.frame_form, width=30, font=('Times', 12))
        self.cusuario.pack(fill=tk.X, padx=10, pady=10)
        self.cusuario.focus()

        tk.Label(self.frame_form, text="Clave:", font=('Times', 14)).pack(fill=tk.X, padx=10, pady=5)
        self.ccontra = tk.Entry(self.frame_form, width=30, font=('Times', 12), show="*")
        self.ccontra.pack(fill=tk.X, padx=10, pady=10)

        self.bregistrar = tk.Button(self.frame_form, text="Login", command=self.validar)
        self.bregistrar.pack(fill=tk.X, padx=10, pady=10)

    def validar(self):
        nick = self.cusuario.get()
        contra = self.ccontra.get()

        user = Users.validar(nick, contra)
        if user:
            messagebox.showinfo("Correcto", "Bienvenido " + user.nick)
            self.mostrar_dashboard(user.nombre, user.apellido)
        else:
            messagebox.showerror("Incorrecto", "Credenciales incorrectos.")

    def mostrar_dashboard(self, nombre, apellido):
        Dashboard(self, nombre, apellido) 
        self.withdraw()  

class Dashboard(tk.Toplevel):
    def __init__(self, parent, nombre, apellido):
        super().__init__(parent)
        self.title("Inicio")
        self.geometry("400x200")
        tk.Label(self, text="Bienvenido " + nombre + " " + apellido + "!" , font=('Times', 20)).pack(pady=50)
        tk.Button(self, text="Salir", command=self.cerrar).pack(pady=20)

    def cerrar(self):
        self.destroy()
        self.master.deiconify() 

Users.agregar_usuario(Users("1101444080", "angie", "Angie", "Milena", "1234" ))

if __name__ == "__main__":
    app = Login()
    app.mainloop()
