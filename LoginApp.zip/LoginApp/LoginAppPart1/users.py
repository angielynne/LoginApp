class Users:

    usuarios_map = {}
    
    def __init__(self, cedula, nick, nombre, apellido, contra):
        self.cedula = cedula
        self.nick = nick
        self.nombre = nombre
        self.apellido = apellido
        self.contra = contra


    @classmethod
    def agregar_usuario(cls, user):
        cls.usuarios_map[user.nick] = user


    @classmethod
    def validar(cls, nick, contra):
        user = cls.usuarios_map.get(nick)
        if user and user.contra == contra:
            return user
        return None
